package com.bookstore.service;

import com.bookstore.dto.RegisterRequest;
import com.bookstore.entity.User;

public interface UserService {
    User findByEmail(String email);
    Object register(RegisterRequest request);
}
