package com.bookstore.service.impl;

import com.bookstore.dto.BookDto;
import com.bookstore.entity.Book;
import com.bookstore.exception.ResourceNotFoundException;
import com.bookstore.repository.BookRepository;
import com.bookstore.service.BookService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final ModelMapper modelMapper;

    public BookServiceImpl(BookRepository bookRepository, ModelMapper modelMapper) {
        this.bookRepository = bookRepository;
        this.modelMapper = modelMapper;
    }

    private BookDto toDto(Book book) { return modelMapper.map(book, BookDto.class); }
    private Book toEntity(BookDto dto) { return modelMapper.map(dto, Book.class); }

    @Override
    public BookDto createBook(BookDto dto) {
        Book entity = toEntity(dto);
        Book saved = bookRepository.save(entity);
        return toDto(saved);
    }

    @Override
    public BookDto updateBook(Long id, BookDto dto) {
        Book existing = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found: " + id));
        existing.setTitle(dto.getTitle());
        existing.setDescription(dto.getDescription());
        existing.setPrice(dto.getPrice());
        existing.setStockQuantity(dto.getStockQuantity());
        Book updated = bookRepository.save(existing);
        return toDto(updated);
    }

    @Override
    public BookDto getBookById(Long id) {
        return bookRepository.findById(id).map(this::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found: " + id));
    }

    @Override
    public List<BookDto> getAllBooks() {
        return bookRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public void deleteBook(Long id) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found: " + id));
        bookRepository.delete(book);
    }
}
