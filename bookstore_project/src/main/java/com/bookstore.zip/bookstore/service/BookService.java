package com.bookstore.service;

import com.bookstore.dto.BookDto;

import java.util.List;

public interface BookService {
    BookDto createBook(BookDto dto);
    BookDto updateBook(Long id, BookDto dto);
    BookDto getBookById(Long id);
    List<BookDto> getAllBooks();
    void deleteBook(Long id);
}
