//package com.bookstore.service.impl;
//
//import com.bookstore.dto.RegisterRequest;
//import com.bookstore.entity.User;
//import com.bookstore.repository.UserRepository;
//import com.bookstore.service.UserService;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.util.Collections;
//
//@Service
//public class UserServiceImpl implements UserService {
//
//    private final UserRepository userRepository;
//    private final PasswordEncoder passwordEncoder;
//
//    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
//        this.userRepository = userRepository;
//        this.passwordEncoder = passwordEncoder;
//    }
//
//    @Override
//    public User findByEmail(String email) {
//        return userRepository.findByEmail(email).orElse(null);
//    }
//
//    @Override
//    public Object register(RegisterRequest request) {
//        User user = User.builder()
//                .username(request.getUsername())
//                .email(request.getEmail())
//                .passwordHash(passwordEncoder.encode(request.getPassword()))
//                .roles(Collections.singleton("USER"))
//                .build();
//        User saved = userRepository.save(user);
//        return saved.getEmail();
//    }
//}


package com.bookstore.service.impl;

import com.bookstore.dto.RegisterRequest;
import com.bookstore.entity.RoleType;
import com.bookstore.entity.User;
import com.bookstore.repository.UserRepository;
import com.bookstore.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository repo;
    private final PasswordEncoder encoder;

    public UserServiceImpl(UserRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }
    
    
    @Override
    public List<User> getAllUsers() {
        return repo.findAll();
    }


    @Override
    public User findByEmail(String email) {
        return repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found: " + email));
    }

    @Override
    public User register(RegisterRequest request) {

        // Always assign default USER role on registration
        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .passwordHash(encoder.encode(request.getPassword()))
                .roles(Set.of(RoleType.USER))   // ⭐ Default
//                .roles(Set.of(RoleType.ADMIN))

                .build();

        return repo.save(user);
    }
}

