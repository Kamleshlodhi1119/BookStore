package com.bookstore.entity;

public class RoleType {
    public static final String USER = "ROLE_USER";
    public static final String ADMIN = "ROLE_ADMIN";
}
