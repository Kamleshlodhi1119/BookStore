package com.bookstore.dto;

import java.time.LocalDate;

public class RatingDto {

    private Integer rating;
    private String comment;
    private String username;
    private LocalDate ratedDate;

    // getters and setters
}
