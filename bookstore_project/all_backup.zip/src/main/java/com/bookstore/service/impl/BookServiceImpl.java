package com.bookstore.service.impl;

import com.bookstore.dto.BookDto;
import com.bookstore.entity.Author;
import com.bookstore.entity.Book;
import com.bookstore.entity.Rating;
import com.bookstore.exception.ResourceNotFoundException;
import com.bookstore.repository.AuthorRepository;
import com.bookstore.repository.BookRepository;
import com.bookstore.repository.RatingRepository;
import com.bookstore.service.BookService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final RatingRepository ratingRepository;
    private final ModelMapper modelMapper;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository,
			RatingRepository ratingRepository, ModelMapper modelMapper) {
		super();
		this.bookRepository = bookRepository;
		this.authorRepository = authorRepository;
		this.ratingRepository = ratingRepository;
		this.modelMapper = modelMapper;
	}

	@Override
    public BookDto createBook(BookDto dto) {
        Book book = modelMapper.map(dto, Book.class);

        if (dto.getAuthorName() != null && !dto.getAuthorName().isBlank()) {
            Author author = authorRepository.findByName(dto.getAuthorName())
                    .orElseGet(() -> {
                        Author a = new Author();
                        a.setName(dto.getAuthorName());
                        return authorRepository.save(a);
                    });
            book.setAuthor(author);
        }

        return map(bookRepository.save(book));
    }

    @Override
    public BookDto updateBook(Long id, BookDto dto) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found"));

        book.setTitle(dto.getTitle());
        book.setDescription(dto.getDescription());
        book.setPrice(dto.getPrice());
        book.setStockQuantity(dto.getStockQuantity());
        book.setPublishDate(dto.getPublishDate());

        return map(bookRepository.save(book));
    }

    @Override
    public BookDto getBookById(Long id) {
        return map(bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found")));
    }

    @Override
    public List<BookDto> getAllBooks() {
        return bookRepository.findAll()
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }

    @Override
    public void addRating(Long bookId, Integer rating, String comment, String username) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found"));

        Rating r = new Rating();
        r.setRating(rating);
        r.setComment(comment);
        r.setUsername(username);
        r.setBook(book);

        ratingRepository.save(r);
    }

    private BookDto map(Book book) {
        BookDto dto = modelMapper.map(book, BookDto.class);

        if (book.getAuthor() != null) {
            dto.setAuthorName(book.getAuthor().getName());
        }

        double avg = (book.getRatings() == null || book.getRatings().isEmpty())
                ? 0
                : book.getRatings()
                      .stream()
                      .mapToInt(r -> r.getRating())
                      .average()
                      .orElse(0);

        dto.setAverageRating(avg);
        return dto;
    }
}
